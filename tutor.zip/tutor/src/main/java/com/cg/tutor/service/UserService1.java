package com.cg.tutor.service;

import com.cg.tutor.dto.LoginResponse;
import com.cg.tutor.dto.UserDto1;
import com.cg.tutor.entity.LoginRequest;
import com.cg.tutor.entity.Parent;
import com.cg.tutor.entity.Tutor;
import com.cg.tutor.exception.ResourceNotFoundException;

public interface UserService1 {
    public Parent psignup(UserDto1 userDto1);
    public Parent plogin(LoginRequest loginRequest) throws ResourceNotFoundException;
    public Parent pchangePassword(LoginResponse loginResponse)throws ResourceNotFoundException;

    public Tutor tlogin(LoginRequest loginRequest)throws ResourceNotFoundException;
    public Tutor tchangePassword(LoginResponse loginResponse)throws ResourceNotFoundException;
}