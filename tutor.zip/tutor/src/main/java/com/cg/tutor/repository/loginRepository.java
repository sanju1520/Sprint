package com.cg.tutor.repository;

 

import java.util.Optional;

 

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

 

import com.cg.tutor.entity.LoginRequest;
import com.cg.tutor.entity.Parent;
import com.cg.tutor.entity.Tutor;
@Repository
public interface loginRepository extends JpaRepository<LoginRequest,String>{

 

    Parent save(Parent parent);
    Tutor save(Tutor tutor);

 

    Optional<Parent> findByUsername(String username);
    Optional<Tutor> findByusername(String username);
}