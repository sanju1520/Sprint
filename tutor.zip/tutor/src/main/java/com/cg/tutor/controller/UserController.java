package com.cg.tutor.controller;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.cg.tutor.dto.LoginResponse;
import com.cg.tutor.dto.UserDto1;
import com.cg.tutor.entity.LoginRequest;
import com.cg.tutor.exception.ResourceNotFoundException;
import com.cg.tutor.service.UserService1;

 

import static org.springframework.http.ResponseEntity.status;

 


@RestController
@RequestMapping("/api/v1/users")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserController {

 

    @Autowired
    private UserService1 userService;//Service Layer object Autowired

 

    @PostMapping("/signup/parent")
    public ResponseEntity<?> psignup(UserDto1 userDto1){
        return status(201).body(userService.psignup(userDto1));
    }

 

    @PostMapping("/login/parent")
    public ResponseEntity<?> plogin(LoginRequest loginRequest) throws ResourceNotFoundException{
        return status(200).body(userService.plogin(loginRequest));
    }

 


    @PutMapping("/reset-password/parent")
    public ResponseEntity<?> pchangePassword(LoginResponse loginResponse) throws ResourceNotFoundException{
        return status(200).body(userService.pchangePassword(loginResponse));
    }

 


    @PostMapping("/login/tutor")
    public ResponseEntity<?> tlogin(LoginRequest loginRequest) throws ResourceNotFoundException{
        return status(200).body(userService.tlogin(loginRequest));
    }

 


    @PutMapping("/reset-password/tutor")
    public ResponseEntity<?> tchangePassword(LoginResponse loginResponse) throws ResourceNotFoundException{
        return status(200).body(userService.tchangePassword(loginResponse));
    }
}
