package com.cg.tutor.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import com.cg.tutor.entity.LoginRequest;
import com.cg.tutor.entity.Parent;
import com.cg.tutor.entity.Tutor;
import com.cg.tutor.exception.UserNotFoundException1;
import com.cg.tutor.repository.loginRepository;

 

public class loginSeviceImpl implements loginService{
    @Autowired
    private loginRepository loginrepository;
    @Override
    public Parent addParent(Parent parent) {
        Parent newparent=loginrepository.save(parent);
        return newparent;
    }

 

    @Override
    public LoginRequest validateParent(String username) {
        Optional<Parent> optionalParent=loginrepository.findByUsername(username);
        if(optionalParent.isEmpty()) {
            throw new UserNotFoundException1("User not found with username"+username);
        }
        return null;
    }
    @Override
    public Tutor addTutor(Tutor tutor) {
        Tutor newtutor=loginrepository.save(tutor);
        return newtutor;
    }

 

    @Override
    public LoginRequest validateTutor(String username) {
        Optional<Tutor> optionalTutor=loginrepository.findByusername(username);
        if(optionalTutor.isEmpty()) {
            throw new UserNotFoundException1("User not found with username"+username);
        }
        return null;
    }
}