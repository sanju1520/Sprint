package com.cg.tutor.service;

import com.cg.tutor.entity.LoginRequest;
import com.cg.tutor.entity.Parent;
import com.cg.tutor.entity.Tutor;

public interface loginService {
    LoginRequest validateParent(String username);
    Parent addParent(Parent parent);
    LoginRequest validateTutor(String username);
    Tutor addTutor(Tutor tutor);
}
