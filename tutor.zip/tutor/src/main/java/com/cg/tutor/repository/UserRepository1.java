package com.cg.tutor.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.tutor.entity.Parent;
import com.cg.tutor.entity.Tutor;
import com.cg.tutor.entity.User;


@Repository
public interface UserRepository1 extends JpaRepository<User, String> {
    Parent findByUsername(String string);
    Tutor findByusername(String string);
    Parent findByEmail(String email);
    Tutor findByemail(String email);
}
