package com.cg.tutor.exception;

 

public class UserNotFoundException1 extends RuntimeException {
public UserNotFoundException1(String message) {
    super(message);
}
}
