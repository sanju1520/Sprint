package com.cg.tutor.exception;

public class TutorNotFoundException extends RuntimeException {
	public TutorNotFoundException(String msg) {
		super(msg);
	}

}
