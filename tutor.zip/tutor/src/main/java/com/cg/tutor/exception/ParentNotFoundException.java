package com.cg.tutor.exception;

public class ParentNotFoundException extends RuntimeException {
	public ParentNotFoundException(String msg) {
		super(msg);
	}
}
